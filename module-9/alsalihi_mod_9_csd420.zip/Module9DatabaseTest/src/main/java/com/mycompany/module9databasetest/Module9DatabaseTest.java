package com.mycompany.module9databasetest;

import java.sql.Connection;
import java.sql.DriverManager;

public class Module9DatabaseTest {

    public static void main(String[] args) {

        String url = "jdbc:mysql://localhost:3306/databasedb";
        String user = "student1";
        String password = "pass";

        try {
            Connection conn = DriverManager.getConnection(url, user, password);

            System.out.println("Database connection successful!");

            conn.close();

        } catch (Exception e) {
            System.out.println("Connection failed.");
            e.printStackTrace();
        }
    }
}